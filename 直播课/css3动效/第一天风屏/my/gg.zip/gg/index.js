(function(){
    var wrapper = document.querySelector(".wrapper")
    var items = document.querySelectorAll(".item")
    var init =  function(){
        items[0].clientWidth
        wrapper.classList.remove("active")
        
    }
    
    init()
})()
// - 为菜单按钮添加点击事件
var btnFlag = true;
var timer = null
var bannerContainer = document.querySelector('.inner-banner');
var banner = document.querySelector('.banner')

document.querySelector('.header-nav-button').onclick = function () {
  headerNavContainer.style.height = btnFlag ? '250px' : '0px'
  btnFlag = !btnFlag;
}

var runAnimation = function () {
  timer = setInterval(function () {
    bannerContainer.style.transition = 'all .5s linear'
    bannerContainer.style.marginLeft = '-100vw'
  }, 3000)
}

//- 动画执行完成监听事件
bannerContainer.addEventListener('transitionend', function () {
  this.appendChild(this.children[0]);
  bannerContainer.style.transition = ''
  bannerContainer.style.marginLeft = '0px'
})


//- 鼠标进入事件
banner.onmouseenter = function () {
  clearInterval(timer)
}
//- 鼠标离开事件
banner.onmouseleave = runAnimation

// - 轮播函数
runAnimation();

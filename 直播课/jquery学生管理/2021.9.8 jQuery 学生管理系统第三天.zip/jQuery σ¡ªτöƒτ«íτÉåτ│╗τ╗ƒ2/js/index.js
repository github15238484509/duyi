var stuData = []; // 存储学生数据
var editId = null; // 存储要修改的学生的 id
var curPage = 1; // 当前页码，默认是第 1 页
var pageNum = null; // 总页码数，一开始为空，后期根据数据来进行计算
var mostNum = 7; // 显示多少个分页

/**
 * 跳转到学生列表
 */
function goToStuList() {
    $('.leftMenuItem').eq(0).addClass('itemActive');
    $('.leftMenuItem').eq(1).removeClass('itemActive');
    $('.rightContent>div').eq(0).removeClass('notShow')
    $('.rightContent>div').eq(1).addClass('notShow')
}

/**
 * 跳转到新增学生或者编辑学生
 * @param {学生 id} id 
 */
function goToAddStu(id) {
    if (id) {
        // 如果进入此 if，说明有 id 传递过来，所以用户是要编辑学生信息
        // 接下来我们就要根据这个 id 去获取数据，然后将数据回填到表单
        $.ajax({
            url: "/getOneStuInfo/",
            type: "POST",
            dataType: "json",
            data: { id },
            success: function (res) {
                // 接下来将返回的数据回填到表单
                $('#stuName').val(res[0].stuName);
                $('#stuEmail').val(res[0].stuEmail);
                $('#stuAge').val(res[0].stuAge);
                $('#stuTel').val(res[0].stuTel);
                $('#stuAddr').val(res[0].stuAddr);
                // 回填性别
                if (res[0].stuGender === "男") {
                    $("#male").prop("checked", true);
                    $("#female").prop("checked", false);
                } else {
                    $("#male").prop("checked", false);
                    $("#female").prop("checked", true);
                }
                editId = res[0].stuId;
                $("#addStuBtn").val("确认修改")
            }
        })
    }
    $('.leftMenuItem').eq(0).removeClass('itemActive');
    $('.leftMenuItem').eq(1).addClass('itemActive');
    $('.rightContent>div').eq(0).addClass('notShow')
    $('.rightContent>div').eq(1).removeClass('notShow')
}

/**
 * 给左侧导航栏绑定点击事件
 */
function changeItem() {
    $('.leftMenu').on('click', '.leftMenuItem', function (e) {
        if ($(e.target).html() === "学生列表") {
            // 点击的是学生列表
            goToStuList();
        } else {
            // 点击的是新增学生
            goToAddStu();
        }
    })
}


/**
 * 渲染内容
 */
function renderContent() {
    // 1. 渲染表格内容
    renderTable(curPage);

    // 2. 渲染分页
    $('#page').page({
        currentPage: curPage, // 当前页码
        totalPage: pageNum, // 总页码数
        mostNumber: mostNum, // 中间最多渲染多少个页码
        // 这是一个回调函数，最新的当前页码数会自动传入到这个回调函数
        // 但是具体做什么由用户来指定
        callBack: renderTable
    })
}

/**
 * 
 * @param {最新的当前页码数} currentPage 
 */
function renderTable(currentPage) {
    // 更新最新的当前页码
    curPage = currentPage;
    // 根据当前页码数，获取对应页码的数据
    // 每一页显示 10 条数据
    // 第一页：stuData.slice(0,10)
    // 第二页：stuData.slice(10,20)
    var arr = stuData.slice((curPage - 1) * 10, curPage * 10);
    // 表头
    var tHead = `
        <thead>
            <tr>
                <th>学号</th>
                <th>姓名</th>
                <th>性别</th>
                <th>邮箱</th>
                <th>年龄</th>
                <th>手机号</th>
                <th>住址</th>
                <th>操作</th>
            </tr>
        </thead>
    `;
    var tBody = arr.map(function (item) {
        return `
            <tr>
                <td>${item.stuId}</td>
                <td>${item.stuName}</td>
                <td>${item.stuGender}</td>
                <td>${item.stuEmail}</td>
                <td>${item.stuAge}</td>
                <td>${item.stuTel}</td>
                <td>${item.stuAddr}</td>
                <td>
                    <button data-id=${item.stuId} class="operationBtn editBtn">编辑</button>
                    <button data-id=${item.stuId} class="operationBtn delBtn">删除</button>
                </td>
            </tr>
        `
    }).join("");
    // $("#stuTable").html(tHead + "<tbody>" + tBody + "</tbody>")
    $("#stuTable").html(`${tHead}<tbody>${tBody}</tbody>`)
}

/**
 * 随机新增一条数据
 */
$('#addStuRandom').click(function () {
    $.ajax({
        url: "/addStuRandom/",
        type: "GET",
        dataType: "json",
        success: function (data) {
            stuData.push(data);
            localStorage.stuData = JSON.stringify(stuData);
            pageNum = Math.ceil(stuData.length / 10);
            curPage = pageNum;
            renderContent();
        }
    })
})

/**
 * 跳转到新增学生的那个表单
 */
$('#addStuBtnByForm').click(function () {
    goToAddStu();
})

// 开始一系列的验证

/**
 * 验证姓名
 */
$('#stuName').blur(function (e) {
    if ($(e.target).val()) {
        $('#validateName').html('')
    } else {
        $('#validateName').html('请填写姓名');
    }
})

/**
 * 验证邮箱
 */
$('#stuEmail').blur(function (e) {
    if ($(e.target).val()) {
        if (/^[\w\.-_]+@[\w-_]+\.com$/.test($(e.target).val())) {
            $('#validateEmail').html('');
        } else {
            $('#validateEmail').html('邮箱格式不正确');
        }
    } else {
        $('#validateEmail').html('请填写邮箱');
    }
})

/**
 * 验证年龄
 */
$("#stuAge").blur(function (e) {
    if ($(e.target).val()) {
        if (isNaN($(e.target).val())) {
            $('#validateAge').html('请填写正确的数字');
        } else {
            if ($(e.target).val() < 0 || $(e.target).val() > 100) {
                $('#validateAge').html('年龄不符合范围要求');
            } else {
                $('#validateAge').html('');
            }
        }
    } else {
        $('#validateAge').html('请填写年龄');
    }
})

/**
 * 添加或者修改学生
 */
$('#addStuBtn').click(function () {
    var arr = $('#addStuForm').serializeArray()
    if (arr.every(function (item) {
        return item.value !== "";
    })) {
        // 接下来还需要判断是否还有不符合要求的
        if ($('.regValidate').toArray().every(function (item) {
            return $(item).html() === ""
        })) {
            // 如果进入此 if，说明可以提交信息
            var newStu = {
                stuName: arr[0].value,
                stuGender: arr[1].value,
                stuEmail: arr[2].value,
                stuAge: arr[3].value,
                stuTel: arr[4].value,
                stuAddr: arr[5].value,
            }

            // 现在我们这个地方就需要一个判断，判断用户是新增还是修改
            // 通过提交按钮的文字来进行判断

            if ($('#addStuBtn').val() === "提交") {
                // 说明用户是新增学生
                // 接下来发送 ajax 请求来新增学生
                $.ajax({
                    url: "/addStuByForm/",
                    type: "POST",
                    dataType: "json",
                    data: newStu,
                    success: function (res) {
                        stuData.push(res);
                        localStorage.stuData = JSON.stringify(stuData);
                        pageNum = Math.ceil(stuData.length / 10);
                        curPage = pageNum;
                        renderContent();
                        goToStuList();
                    }
                })
            } else {
                // 说明用户是修改学生
                newStu.stuId = editId;
                $.ajax({
                    url : "/editStuByForm/",
                    type : "POST",
                    dataType : "json",
                    data : newStu,
                    success : function(res){
                        stuData = res;
                        localStorage.stuData = JSON.stringify(stuData);
                        $("#addStuBtn").val("提交")
                        clearForm();
                        renderContent();
                        goToStuList();
                    }
                })
            }
        } else {
            window.alert("请保证每一项都符合要求");
        }
    } else {
        window.alert("请完善表单的每一项");
    }
})


function clearForm() {
    $('#addStuForm')[0].reset(); // 清空表单
    var spanArr = $('.regValidate');
    for (var i = 0; i < spanArr.length; i++) {
        $(spanArr[i]).html('');
    }
}

/**
 * 返回到学生列表
 */
$('#backStuList').click(function () {
    // 清空一下表单
    clearForm();
    // 跳转回学生列表
    goToStuList();
})

/**
 * 编辑学生
 */
$('#stuTable').on('click', '.editBtn', function (e) {
    goToAddStu(e.target.dataset.id);
})

/**
 * 删除学生
 */
$('#stuTable').on('click','.delBtn',function(e){
    var id = e.target.dataset.id;
    if(window.confirm("是否要删除此名学生？")){
        // 发送 ajax 请求进行删除
        $.ajax({
            url : `/delStu/${id}`,
            type : 'DELETE',
            dataType : 'json',
            success : function(res){
                stuData = res;
                localStorage.stuData = JSON.stringify(stuData);
                // 删除的话总数据的量会减少
                // 重新计算总页码数
                pageNum = Math.ceil(stuData.length / 10);
                if(curPage > pageNum){
                    curPage = pageNum;
                }
                renderContent();
            }
        })
    }
})

/**
 * 搜索学生
 */
$('#searchBtn').click(function(){
    var selectSearchItem = $('#selectSearchItem').val();
    var searchStu = $('#searchStu').val();
    if(searchStu){
        // 进行搜索操作
        $.ajax({
            url : "/searchStu/",
            type : "POST",
            dataType : "json",
            data : {
                selectSearchItem,
                searchStu
            },
            success : function(res){
                if(res.length){
                    stuData = res;
                    pageNum = Math.ceil(res.length / 10);
                    curPage = 1;
                    renderContent();
                } else {
                    $("#stuTable").html("没有找到相关内容");
                    $('#page').html('');
                }
            }
        })
    } else {
        window.alert("请输入要搜索的内容");
    }
})

/**
 * 返回显示所有数据
 */
$('#backBtn').click(function(){
    $('#searchStu').val('');
    stuData = JSON.parse(localStorage.stuData);
    pageNum = Math.ceil(stuData.length  / 10);
    renderContent();
})

/**
 * 第一次进来的时候，初始化本地数据
 */
function initData() {
    $.ajax({
        url: '/getStuData/',
        type: 'GET',
        dataType: 'json',
        success: function ({ data }) {
            // 1. localStorage 要存储一份
            localStorage.stuData = JSON.stringify(data);
            // 2. 本地存储一份，方便操作
            stuData = data;
            // 3. 计算总页码数
            pageNum = Math.ceil(stuData.length / 10);
            // 4. 渲染内容
            renderContent();
        }
    })
}

/**
 * 主函数
 */
function main() {
    // 1. 左侧菜单栏绑定点击事件
    changeItem();
    // 2. 渲染初始的数据
    if (localStorage.stuData) {
        // 说明本地有数据，直接从本地获取数据
        // 1. 从 localStorage 取出数据
        stuData = JSON.parse(localStorage.stuData);
        // 2. 计算总页码数
        pageNum = Math.ceil(stuData.length / 10);
        // 3. 渲染
        renderContent();
    } else {
        // 说明本地没有数据，是第一次进来，那么我们需要初始化数据
        initData();
    }
}
main();
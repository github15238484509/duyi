//- 获取canvas的元素
var canvas = document.getElementById('canvas');
// - 获取一个创建动画的2D对象
var context = canvas.getContext("2d");
// - 调整他的显示位置
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

function snow (x, y) {
  //- 保存画布的原有位置
  context.save();
  //- 开启绘画的路径
  context.beginPath();
  context.translate(x, y)
  //- 旋转雪花
  context.rotate(20 * Math.PI / 180)
  // - 雪花缩放
  context.scale(0.5, 0.5)
  // - 线的起始的位置
  context.moveTo(-20, 0);  //- 画布的线的开始坐标点（从左上角开始计算）
  context.lineTo(20, 0);  //- 线的结束的位置（从左上角开始计算）
  context.strokeStyle = '#fff';
  context.lineWidth = 10;
  context.lineCap = 'round';

  var disX = Math.sin(30 * Math.PI / 180) * 20;
  var disY = Math.sin(60 * Math.PI / 180) * 20;

  //- 第二条线
  context.moveTo(-disX, -disY);
  context.lineTo(disX, disY);
  //- 第三条线
  context.moveTo(-disX, disY);
  context.lineTo(disX, -disY);

  context.stroke();
  context.restore(); // - 绘画之后恢复原来的位置
  context.closePath();  // - 关闭路径
}
//- sin60  = 对边 / 斜边  => 对边 = sin60 * 斜边

//-  实现多雪花的制作（创建一个制作雪花的构造函)

function Snow (x, y, scale, rotate, speedX, speedY, speedR) {
  this.x = x;
  this.y = y;
  this.scale = scale;
  this.rotate = rotate;
  this.speedX = speedX;
  this.speedY = speedY;
  this.speedR = speedR;
}

Snow.prototype.render = function () { // - 所有的雪花生成的过程都是使用构造函数上面原型的方法 公用一个实例 节省内存
  context.save();
  context.beginPath();
  context.translate(this.x, this.y)
  context.rotate(this.rotate * Math.PI / 180)
  context.scale(this.scale, this.scale)
  context.moveTo(-20, 0);
  context.lineTo(20, 0);
  context.strokeStyle = '#fff';
  context.lineWidth = 10;
  context.lineCap = 'round';

  var disX = Math.sin(30 * Math.PI / 180) * 20;
  var disY = Math.sin(60 * Math.PI / 180) * 20;
  //- 第二条线
  context.moveTo(-disX, -disY);
  context.lineTo(disX, disY);
  //- 第三条线
  context.moveTo(-disX, disY);
  context.lineTo(disX, -disY);

  context.stroke();
  context.restore(); // - 绘画之后恢复原来的位置
  context.closePath();  // - 关闭路径
}


var snow = new Snow(50, 50, 1, 10, 10, 10, 10);

var snowList = [];

var init = function () {
  for (var i = 0; i < 100; i++) {
    var x = Math.random() * canvas.width;
    var scale = Math.random() + 0.5;
    var rotate = Math.random() * 60;
    var speedX = Math.random() + 1;
    var speedY = Math.random() + 5;
    var speedR = Math.random() * 4 + 2;

    (function (x, scale, rotate, speedX, speedY, speedR) {
      setTimeout(function () {
        var snow = new Snow(x, 0, scale, rotate, speedX, speedY, speedR)
        snow.render();
        snowList.push(snow)
      }, Math.random() * 8000)

    })(x, scale, rotate, speedX, speedY, speedR)
  }
  snowIng();
}


//- 创建一个运动函数
var snowIng = function () {
  //- 收集这100个雪花
  //- 创建定时器，不断地调整x与y轴的位置信息
  setInterval(function () {
    context.clearRect(0, 0, canvas.width, canvas.height);
    for (var i = 0; i < snowList.length; i++) {
      snowList[i].x = (snowList[i].x + snowList[i].speedX) % canvas.width;
      snowList[i].y = (snowList[i].y + snowList[i].speedY) % canvas.height;
      snowList[i].rotate = (snowList[i].rotate + snowList[i].speedR) % 60
      snowList[i].render()
    }
  }, 30)
}

init();
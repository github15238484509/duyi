// import { get, post } from './http'
import { post } from './http'
export const apiAddress = p => post('ap_before', p);
export const apiAddress132 = p => post('ap_before', p);
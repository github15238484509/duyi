// 思考：如何给 jQuery 扩展内容或者说方法？
// 扩展提问：$.extend 和 $.fn.extend 区别？
// $.extend : 给 jQuery 类本身扩展方法
// $.fn.extend : 给 jQuery 实例对象扩展方法


$.fn.extend({
    // options 是一个配置对象，由使用插件的用户传递过来的
    // this 代表的轮播图容器节点
    swiper: function (options) {
        var obj = new Swiper(options, this); // 实例化 Swiper 对象
        obj.init();
    }
})

/**
 * 
 * @param {配置对象} options 
 * @param {轮播图容器节点对象，是一个 jQuery 对象} wrap 
 */
function Swiper(options, wrap) {
    // 首先第一步，我们对对象进行一个初始化
    this.wrap = wrap; // 保存轮播图的外层容器节点
    this.contentList = options.contentList || []; // 轮播的内容列表
    this.autoChangeTime = options.autoChangeTime || 5000; // 自动播放时间
    this.type = options.type || 'fade'; // 播放的方式
    this.isAuto = options.isAuto === undefined ? true : !!options.isAuto;// 是否自动轮播
    // 左右按钮的显示状态，共有 3 种 
    // 1. always 代表一支显示   2. hide 代表隐藏    3. hover 移入显示
    this.showChangeBtn = options.showChangeBtn || 'always';
    // 是否显示小圆点
    this.showSpots = options.showSpots == undefined ? true : !!options.showSpots;
    // 小圆点的大小
    this.spotSize = options.spotSize || 5;
    // 小圆点的位置，可选值有 3 个 
    // 1. left 2. center 3. right
    this.spotPosition = options.spotPosition || 'center';
    // 小圆点的背景颜色
    this.spotColor = options.spotColor || "rgba(255,255,255,.4)";
    // 当前图片的小圆点的颜色
    this.curSpotColor = options.curSpotColor || "red";
    this.width = options.width || $(wrap).width(); // 轮播图容器的宽度
    this.height = options.height || $(wrap).height(); // 轮播图容器的高度


    // 除开上面用户传递的属性，我们保存在了 Swiper 实例对象上面
    // 还有一些属性，这些是用户没有传递
    this.len = this.contentList.length; // 轮播图项目的长度
    this.nowIndex = 0; // 当前轮播的索引值
    this.timer = null; // 自动轮播的计时器
    this.lock = false; // 是否执行切换动画
}

// 初始化轮播图的方法
Swiper.prototype.init = function () {
    // 主要要做的事情有 3 个
    // 1. 创建轮播图结构（这个结构才是最终渲染到浏览器的 DOM 结构）
    this.createElement();


    // 2. 初始化轮播图的样式
    // 3. 绑定功能

}

// 创建轮播图结构方法
Swiper.prototype.createElement = function () {
    // 1. 创建对应的结构

    // 整个轮播图的包裹层
    var swiperWrapper = $('<div class="my-swiper-wrapper"></div>');
    // 轮播图的内容区
    var swiperItems = $('<ul class="my-swiper-items"></ul>');
    // 轮播图小圆点区域
    var spotsWrapper = $('<div class="my-swiper-spots"></div>')
    // 左右按钮
    var leftBtn = $('<div class="my-swiper-btn my-swiper-lbtn"><i class="iconfont">&#xe628;</i></div>')
    var rightBtn = $('<div class="my-swiper-btn my-swiper-rbtn"><i class="iconfont">&#xe625;</i></div>')

    // 接下来，我们需要将用户传递过来的具体轮播项目添加到轮播图的内容区
    for (var i = 0; i < this.len; i++) {
        // 往轮播图的内容区添加 li
        $("<li class='my-swiper-item'></li>").html(this.contentList[i]).appendTo(swiperItems);
        // 添加对应的小圆点
        $("<span></span>").appendTo(spotsWrapper)
    }


    // 2. 不是所有的结构都是一样的
    // 如果是从左到右的轮播，我们的 DOM 结构稍微有些不一样，需要做特殊处理
    if(this.type === 'animate'){
        // 进入此 if，说明用户选择的是从左到右的轮播
        // 那么我们要实现无缝轮播，所以最后要添加一个第一张图片
        swiperItems.append($("<li class='my-swiper-item'></li>").html($(this.contentList[0]).clone(true)));
    }


    // 3. 根据用户选择是否显示左右按钮，结构上还要做处理
    switch(this.showChangeBtn){
        case 'hide' : {
            leftBtn.hide();
            rightBtn.hide();
            break;
        }
        case 'hover' : {
            // 先把添加的按钮隐藏掉，再设置 hover 方法
            leftBtn.hide();
            rightBtn.hide();
            swiperWrapper.hover(function(){
                leftBtn.show();
                rightBtn.show();
            },function(){
                leftBtn.hide();
                rightBtn.hide();
            });
            break;
        }
        default : {
            // 默认 always
            break;
        }
    }

    // 4. 设置小圆点是否要显示
    if(!this.showSpots){
        // 进入此 if，说明用户不要显示小圆点
        spotsWrapper.hide();
    }

    swiperWrapper.append(swiperItems).append(leftBtn).append(rightBtn).append(spotsWrapper).appendTo(this.wrap);

}
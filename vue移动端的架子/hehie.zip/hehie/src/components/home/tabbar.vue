<template>
    <van-tabbar style="border-top:1px solid #eaeaea" v-model="active">
      <van-tabbar-item replace to="/workbench">
        <span>工作台</span>
        <template #icon="props">
          <img
            :src="props.active ? icon.workbench : icon.inworkbench"
          /> </template
      ></van-tabbar-item>
      <van-tabbar-item replace to="/placeorder">
        <span>下单</span>
        <template #icon="props">
          <img :src="props.active ? icon.xiadan : icon.inxiadan" /> </template
      ></van-tabbar-item>
      <van-tabbar-item replace to="/examine">
        <span>审批</span>
        <template #icon="props">
          <img :src="props.active ? icon.shenpi : icon.inshenpi" /> </template
      ></van-tabbar-item>
      <van-tabbar-item replace to="/readme" badge="3">
        <span>我的</span>
        <template #icon="props">
          <img :src="props.active ? icon.me : icon.inme" />
        </template>
      </van-tabbar-item>
    </van-tabbar>
</template>

<script>
export default {
  data() {
    return {
      active: 0,
      icon: {
        me: require("@/assets/homeimg/me.png"),
        inme: require("@/assets/homeimg/me1.png"),
        shenpi: require("@/assets/homeimg/shenpi1.png"),
        inshenpi: require("@/assets/homeimg/shenpi.png"),
        xiadan: require("@/assets/homeimg/xiadan.png"),
        inxiadan: require("@/assets/homeimg/xiadan1.png"),
        workbench: require("@/assets/homeimg/workbench.png"),
        inworkbench: require("@/assets/homeimg/workbench1.png"),
      },
    };
  },
};
</script>

<style lang="sass" scoped>
</style>
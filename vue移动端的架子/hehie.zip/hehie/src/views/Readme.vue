<template>
  <div>这是我的</div>
</template>

<script>
export default {
 name:'Readme',
 created(){
   console.log(74444);
 }
};
</script>

<style lang="less" scoped>
</style>
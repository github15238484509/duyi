<template>
  <div>
      这是审批
  </div>
</template>

<script>
export default {
  name:'Examine'
}
</script>

<style lang="less" scoped>

</style>
(function () {
  // - 背景颜色
  var bodyBg = ['#F7E8ED', '#F2D9E6', '#ECC6DE', '#E0ECF5', '#DDF4DE', '#F0F1D5', '#EEDECD', '#B8E6B3', '#ABE3D8', '#E0E1F5', '#F7E8ED', '#F2D9E6', '#E0ECF5', '#DDF4DE', '#F0F1D5', '#EEDECD', '#B8E6B3', '#ABE3D8', '#DFD1F0', '#6161616'];


  var init = function () {
    addBoxStyle();
    initEvents();
  }

  var initEvents = function () {
    document.querySelectorAll('.box').forEach(function (box) {
      box.children[0].addEventListener('mouseenter', onBoxMouseenter)
      box.addEventListener('mouseleave', onBoxMouseleave)
    })
    document.addEventListener('mousemove', onContentMouseMove)
  }

  //- 鼠标离开盒子
  var onBoxMouseleave = function () {
    this.style.transform = ''
  }

  // - 盒子的鼠标进入事件
  var onBoxMouseenter = function (e) {
    var top = this.getBoundingClientRect().top
    var right = this.getBoundingClientRect().right
    var bottom = this.getBoundingClientRect().bottom
    var left = this.getBoundingClientRect().left
    var mouseX = e.clientX
    var mouseY = e.clientY
    //- 求得当前进入得最小值
    var distanceT = Math.abs(mouseY - top);
    var distanceR = Math.abs(mouseX - right);
    var distanceB = Math.abs(mouseY - bottom);
    var distanceL = Math.abs(mouseX - left);
    var minNum = Math.min(distanceT, distanceR, distanceB, distanceL)
    var transitionArr = ['rotateX(-180deg)', 'rotateY(-180deg)', 'rotateX(180deg)', 'rotateY(180deg)']
    var index = null;
    switch (minNum) {
      case distanceT:
        index = 0;
        break
      case distanceR:
        index = 1
        break
      case distanceB:
        index = 2
        break
      case distanceL:
        index = 3
        break
    }
    this.parentNode.style.transform = 'translateZ(150px)' + transitionArr[index];
    document.body.style.background = bodyBg[Math.round(Math.random() * (bodyBg.length - 1))]
  }


  //- 添加盒子的背景颜色以及背景图片 一般的在写一些插件（给别人用的）的时候
  var addBoxStyle = function () {
    var boxBg = ['#f44336', '#e91e63', '#9c27b0', '#673ab7', '#3f51b5', '#2196f3', '#03a9f4', '#00bcd4', '#009688', '#4caf50', '#8bc34a', '#cddc39', '#ffeb3b', '#ffc107', '#ff9800', '#ff5722', '#795548', '#564545', '#607d8b', '#405d6b', '#9e9e9e', '#70737d', '#389fa0', '#38a05e', '#b3c981', '#76a803', '#fecf43', '#e2785f'];
    //- 创建一个style标签
    var style = document.createElement('style')
    var str = ''
    //- style标签添加内容（样式属性）
    boxBg.forEach(function (item, index) {
      str += `.box:nth-child(${index + 1}) div{background:${item} url(./img/${index + 1}.png) no-repeat center}`
    })
    style.innerHTML = str
    //- 插入到head标签里面
    document.head.appendChild(style)
  }

  // - 鼠标移动，内容显示改变
  var onContentMouseMove = function (e) {
    // console.log(e.clientX, window.innerWidth)
    var y = (e.clientX / window.innerWidth - 0.5) * 15
    var x = (0.5 - e.clientY / window.innerHeight) * 15
    document.querySelector('.content').style.transform = `perspective(1500px) rotateX(${x}deg) rotateY(${y}deg)`
  }




  init();
})()
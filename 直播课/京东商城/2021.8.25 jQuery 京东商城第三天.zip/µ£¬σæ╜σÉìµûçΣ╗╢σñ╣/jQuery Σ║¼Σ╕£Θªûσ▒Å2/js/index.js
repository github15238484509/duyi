// 加载 shortcut 模块中的内容
$('.shortcut .w').load('../components/shortcut.html');

// 加载 header 模块内容
$('.header .w').load('../components/header.html');
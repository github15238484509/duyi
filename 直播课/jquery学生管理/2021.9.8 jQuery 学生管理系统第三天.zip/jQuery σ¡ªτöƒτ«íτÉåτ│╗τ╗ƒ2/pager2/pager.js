$.fn.extend({
    page: function (options) {
        new Pager(options, this).init();
    }
})

// `` 是 ES6 新增的字符串模板语法，最大的特点是可以解析变量
// var name = "xiejie";
// console.log("Hello," + name);
// console.log(`Hello,${name}`); // Hello,xiejie

/**
 * 
 * @param {用户传递的配置对象} options 
 * @param {分页的容器} wrap 
 */
function Pager(options, wrap) {
    // 这里就把用户传递的配置对象的信息存储到了 Pager 实例对象上面
    this.wrap = wrap;
    this.currentPage = options.currentPage || 1;
    this.totalPage = options.totalPage || 1;
    this.mostNumber = options.mostNumber || 1;
    this.callBack = options.callBack || function () { }
}

/**
 * 初始化分页组件
 */
Pager.prototype.init = function () {
    // 1. 初始化分页的结构
    this.createElement();

    // 2. 绑定事件
    this.bindEvent();
}

/**
 * 
 * @param {渲染出来的字符串放在哪里} center 
 * @param {开始的页码编号} liStartNum 
 * @param {结束的页码编号} liEndNum 
 */
Pager.prototype.createLi = function (center, liStartNum, liEndNum) {
    for (var i = liStartNum; i <= liEndNum; i++) {
        if(this.currentPage === i){
            center += `<li class="currentPage pageNum">${i}</li>`
        } else {
            center += `<li class="pageNum">${i}</li>`
        }
    }
    return center;
}

/**
 * 创建分页的结构
 */
Pager.prototype.createElement = function () {
    // 一进来先清空内容
    this.wrap.html('');
    // 先书写固定的结构
    var pageWrapper = $('<ul id="pageSelect" class="pagination"></ul>')
    var left = '<li class="prevPage">&lt;</li>' // 上一页
    var right = '<li class="nextPage">&gt;</li>' // 下一页
    var center = ""; // 中间部分，需要使用循环来生成

    if (this.totalPage < this.mostNumber) {
        // 所有的页码都要渲染出来
        center = this.createLi(center,1,this.totalPage);
    } else {
        // 不用所有的页码渲染出来，渲染一部分就好了，其余的使用 ...
        // 省略号分为三种情况
        if(this.currentPage < 3){
            // 省略号在后面
            center = this.createLi(center, 1, 3);
            center += "....." + `<li class="pageNum">${this.totalPage}</li>`
        } else if(this.currentPage > this.totalPage - 3){
            // 省略号在前面
            center += `<li class="pageNum">1</li>.....`;
            center = this.createLi(center,this.totalPage - 3, this.totalPage);
        } else {
            // 当前页在中间，省略号拼接在两边
            center += `<li class="pageNum">1</li>.....`;
            center = this.createLi(center,this.currentPage - 2, this.currentPage + 2);
            center += "....." + `<li class="pageNum">${this.totalPage}</li>`
        }

    }
    pageWrapper.html(left + center + right).appendTo(this.wrap);
}

/**
 * 绑定事件
 */
Pager.prototype.bindEvent = function () {
    var self = this;
    // 上一页
    $('.prevPage').click(function(){
        self.currentPage--;
        if(!self.currentPage){
            self.currentPage = 1;
            window.alert("当前已经是第一页了");
            return;
        }
        self.init();
        self.callBack(self.currentPage);
    })
    // 下一页
    $('.nextPage').click(function(){
        self.currentPage++;
        if(self.currentPage > self.totalPage){
            self.currentPage = self.totalPage;
            window.alert("当前已经是最后一页了");
            return;
        }
        self.init();
        self.callBack(self.currentPage);
    })
    // 具体页码
    $('.pageNum').click(function(){
        self.currentPage = parseInt($(this).text())
        self.init();
        self.callBack(self.currentPage);
    })
}
<template>
  <div>
      这是下单
  </div>
</template>

<script>
export default {
    name:'Placeorder'
}
</script>

<style lang="less" scoped>

</style>
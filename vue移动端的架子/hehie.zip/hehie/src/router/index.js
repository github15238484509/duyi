import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home,
    redirect: '/login',
    meta: {
      title: '首页'
    }
  },
  {
    path: '/login',
    name: 'Login',
    meta: {
      title: '登录',
      keepAlive: false
    },
    component: () => import('../views/Login.vue')

  },
  {
    path: '/workbench',
    name: 'Workbench',
    meta: {
      title: '工作台',
      keepAlive: false
    },
    component: () => import('../views/Workbench.vue')

  }, {
    path: '/placeorder',
    name: 'Placeorder',
    meta: {
      title: '下单',
      keepAlive: false
    },
    component: () => import('../views/Placeorder.vue')
  },
  {
    path: '/examine',
    name: 'Examine',
    meta: {
      title: '审批',
      keepAlive: false
    },
    component: () => import('../views/Examine.vue')
  },
  {
    path: '/readme',
    name: 'Readme',
    meta: {
      title: '我的',
      keepAlive: false
    },
    component: () => import('../views/Readme.vue')
  },
  // {
  //   path: '/about',
  //   name: 'About',
  //   component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  // }
]

const router = new VueRouter({
  mode: 'hash',
  base: process.env.BASE_URL,
  routes
})
// 全局解析守卫
router.afterEach((to) => {
  document.title = to.meta.title
})
export default router
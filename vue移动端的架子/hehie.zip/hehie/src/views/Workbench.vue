<template>
  <div>
      这是工作台
  </div>
</template>

<script>
export default {
    name:'Workbench'
}
</script>

<style lang="less" scoped>

</style>
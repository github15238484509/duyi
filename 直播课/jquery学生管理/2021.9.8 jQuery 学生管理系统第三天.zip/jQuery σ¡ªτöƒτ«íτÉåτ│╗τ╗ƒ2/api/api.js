// 该文件用于拦截 ajax 请求，提供 fake 数据

var template = {
    "stuId|+1": 1,
    "stuName": "@cname()",
    "stuGender": /[男女]/,
    "stuEmail": "@email()",
    "stuAge|20-30": 1,
    "stuTel": /^1[3578][1-9]\d{8}$/,
    "stuAddr": "@city",
}

// 做一个数据的初始化
Mock.mock('/getStuData/', function () {
    return Mock.mock({
        "status": "success",
        "msg": "请求数据成功",
        "data|5": [template]
    })
})

// 随机新增一条学生数据
Mock.mock("/addStuRandom/", function () {
    // 这里正常来讲，是连接数据新增数据
    // 因为我们这里没有数据库，我们就返回新增的学生数据
    var newStu = Mock.mock({
        "list": template
    })
    var stuData = JSON.parse(localStorage.stuData);
    newStu.list.stuId = parseInt(stuData[stuData.length - 1].stuId) + 1;
    // 返回这条新增的数据
    return newStu.list;
})


/**
 * 
 * @param {是一个 keyu=value&key=value 的字符串} queryStr 
 */
function queryToObj(queryStr) {
    var result = {};
    var queryArr = queryStr.split("&");
    for (var i of queryArr) {
        var arr = i.split('=');
        var key = arr[0];
        var value = arr[1];
        result[key] = value
    }
    return result;
}


// 手动新增一条学生数据
Mock.mock("/addStuByForm/", "post", function (option) {
    var newStu = queryToObj(decodeURIComponent(option.body))
    var stuData = JSON.parse(localStorage.stuData);
    newStu.stuId = parseInt(stuData[stuData.length - 1].stuId) + 1;
    return newStu;
})

// 根据 id 获取一条对应 id 的学生信息
Mock.mock("/getOneStuInfo/", "post", function (option) {
    var id = queryToObj(decodeURIComponent(option.body)).id
    // 这里正常的逻辑应该是连接数据库，从数据库里面取出对应 id 的学生数据
    // 但是我们这会儿没有数据库
    var stuData = JSON.parse(localStorage.stuData);
    return stuData.filter(function (item) {
        return item.stuId == id
    })
})

// 修改学生
Mock.mock("/editStuByForm/", 'post', function (option) {
    var newStu = queryToObj(decodeURIComponent(option.body));
    // 找到 localStorage 里面对应的这条学生数据，进行一个替换
    var stuData = JSON.parse(localStorage.stuData);
    for (var i = 0; i < stuData.length; i++) {
        if (stuData[i].stuId === parseInt(newStu.stuId)) {
            stuData.splice(i, 1, newStu);
            break;
        }
    }
    return stuData;
})

// 删除学生
Mock.mock(RegExp('/delStu/?[\w\W]*'), 'delete', function (option) {
    var id = option.url.split('/')[2];
    // 这里正常的逻辑应该是连接数据库，从数据库里面取出对应 id 的学生数据
    // 但是我们这会儿没有数据库
    var stuData = JSON.parse(localStorage.stuData);
    for (var i = 0; i < stuData.length; i++) {
        if (stuData[i].stuId == parseInt(id)) {
            stuData.splice(i, 1);
            break;
        }
    }
    return stuData;
})


// 搜索学生
Mock.mock("/searchStu/","post",function(option){
    var searchInfo = queryToObj(decodeURIComponent(option.body));
    var stuData = JSON.parse(localStorage.stuData);
    switch(searchInfo.selectSearchItem){
        case "stuId" : {
            // 按照学号来进行搜索
            return stuData.filter(function(item){
                return item.stuId == searchInfo.searchStu
            })
        }
        case "stuName" : {
            // 按照姓名来进行搜索
            return stuData.filter(function(item){
                return item.stuName == searchInfo.searchStu
            })
        }
    }
})
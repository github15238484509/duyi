# jQuery 京东首屏第三天笔记



今日目标：



- 搭建项目结构
- 书写首屏整体布局
- 完成首屏顶上快捷区域
- 完成头部区域



## 搭建项目结构



通过前面两天的学习，我们已经封装好了我们通用的轮播图插件。

从今天开始，我们就正式来书写我们的京东首屏。



那么，项目开始之前，我们需要搭建我们的项目目录。

整个目录如下：



<img src="https://xiejie-typora.oss-cn-chengdu.aliyuncs.com/2021-08-25-070526.png" alt="image-20210825150526650" style="zoom:50%;" />



这其中，*swiper* 是我们前两天封装的轮播图组件，*HTML、CSS、JS* 各自分门别类的放在各自目录下。

其中 *JS* 目录下存放了 *jquery* 以及 *mock* 文件



## 书写首屏整体布局



接下来，我们就开始书写我们首屏的整体布局了。

首先在 *index.html* 中设置标题和 *icon*。这个标题和 *icon* 从哪里获取呢？

我们可以直接从官网获取：



<img src="https://xiejie-typora.oss-cn-chengdu.aliyuncs.com/2021-08-25-070915.png" alt="image-20210825150914885" style="zoom:50%;" />



在官网点击鼠标右键，选择【显示网页源码】，然后在官网源码中就能够获取到，如下图所示：

![image-20210825151035813](https://xiejie-typora.oss-cn-chengdu.aliyuncs.com/2021-08-25-071035.png)



设置完成后，我们就可以看到我们的网页无论是标题还是 *icon* 都和官网一模一样。



<img src="https://xiejie-typora.oss-cn-chengdu.aliyuncs.com/2021-08-25-071149.png" alt="image-20210825151149552" style="zoom:50%;" />



接下来就开始划分区块，我们整个页面大致能分为如下的区域：



![image-20210825152832695](https://xiejie-typora.oss-cn-chengdu.aliyuncs.com/2021-08-25-072833.png)



可以看到，我们将整个首屏页面分为了 *4* 个部分：



- 快捷区域
- 头部区域
- 轮播区域
- 京东秒杀区域



其中，轮播区域又可以分为 *3* 块，如下图：



![image-20210825152435437](https://xiejie-typora.oss-cn-chengdu.aliyuncs.com/2021-08-25-072436.png)



明白了基本结构后，那我们的代码也就出来了：



```html
<!-- 最上面的快捷区域，是一个通栏 -->
<div class="shortcut">
  <!-- 中间区域 -->
  <div class="w"></div>
</div>
<!-- 头部区域 -->
<div class="header">
  <!-- 中间区域 -->
  <div class="w"></div>
</div>
<!-- 轮播图区域 -->
<div class="fs w">
  <!-- 轮播图左边 menu 区域 -->
  <div class="fs-1"></div>
  <!-- 轮播图中间 -->
  <div class="fs-2">
    <div class="sliderWrapper"></div>
    <div class="sliderBanner"></div>
  </div>
  <!-- 轮播图右侧 user 区域 -->
  <div class="fs-3"></div>
</div>
<!-- 秒杀区域 -->
<div class="seckill w"></div>
```



由于快捷区域和头部区域是有一个通栏效果，所以我们在里面嵌套了一个 *div.w*，外层 *div* 做通栏，里面 *div* 做中间内容区域。

轮播图区域分为左中右 *3* 个部分，分别对应 *fs-1、fs-2、fs-3*。其中 *fs-2* 又分为 *2* 个区域 *sliderWrapper* 和 *sliderBanner*



结构搞定后，接下来来书写各个区域的整体样式



在通用样式中，我们设置了字体、清除浮动辅助类、*li、a、i* 等通用样式，如下：

```css
/* 通用样式开始 */

@font-face {
    font-family: 'iconfont';
    src: url('http://at.alicdn.com/t/font_2289209_k45eprt6cm.eot');
    src: url('http://at.alicdn.com/t/font_2289209_k45eprt6cm.eot?#iefix') format('embedded-opentype'), url('http://at.alicdn.com/t/font_2289209_k45eprt6cm.woff2') format('woff2'), url('http://at.alicdn.com/t/font_2289209_k45eprt6cm.woff') format('woff'), url('http://at.alicdn.com/t/font_2289209_k45eprt6cm.ttf') format('truetype'), url('http://at.alicdn.com/t/font_2289209_k45eprt6cm.svg#iconfont') format('svg');
}

* {
    padding: 0;
    margin: 0;
}

body {
    background-color: #eee;
}

.w {
    width: 1190px;
    margin: 0 auto;
    min-height: 100%;
}

.iconfont {
    font-family: iconfont;
    font-style: normal;
    font-size: 12px;
    display: inline-block;
    width: 12px;
}

.clearfix::after {
    content: "";
    display: block;
    clear: both;
}

li {
    list-style: none;
}

a {
    text-decoration: none;
}

i {
    font-style: normal;
}

/* 通用样式结束 */
```



快捷区域和头部区域给一个背景色占位

```css
/* 快捷区域样式开始 */

.shortcut {
    height: 30px;
    border-bottom: 1px solid #ddd;
    background-color: #e3e4e5;
}

/* 快捷区域样式结束 */

/* 头部区域样式开始 */

.header {
    height: 140px;
    background: #fff;
    border-bottom: 1px solid #ddd;
}

/* 头部区域样式结束 */
```



轮播区域设置每个部分的宽度占比，然后给个背景色占位

```css
/* 轮播图区域样式开始 */

.fs {
    height: 470px;
    margin-top: 10px;
    /* outline: 1px solid; */
}

.fs-1 {
    width: 190px;
    background-color: #fff;
    height: 100%;
    float: left;
    margin-right: 10px;
    /* outline: 1px solid; */
}

.fs-2 {
    float: left;
    width: 790px;
    height: 100%;
    margin-right: 10px;
    /* outline: 1px solid; */
}

.fs-3 {
    float: right;
    width: 190px;
    background-color: #fff;
    height: 100%;
    /* outline: 1px solid; */
}

.fs-2 .sliderWrapper {
    width: 590px;
    height: 470px;
    float: left;
    background-color: #ddd;
    /* outline: 1px solid; */
}

.fs-2 .sliderBanner {
    width: 190px;
    height: 470px;
    float: right;
    background-color: #ddd;
    /* outline: 1px solid; */
}

/* 轮播图区域样式结束 */
```



最后是秒杀区域，设置高度，颜色占位

```css
/* 秒杀区域样式开始 */

.seckill {
    height: 260px;
    margin-top: 20px;
    background-color: #ddd;
    /* outline: 1px solid; */
}

/* 秒杀区域样式结束 */
```



书写完毕后的整体效果如下：

<img src="https://xiejie-typora.oss-cn-chengdu.aliyuncs.com/2021-08-25-074545.png" alt="image-20210825154544883" style="zoom:50%;" />



## 模块化开发



区域划分完成后，我们就要开始书写各个区域的代码了。

但是本次开发，我们将采用模块化的方式来进行开发，而不是把所有的 *HTML、CSS、JS* 写在各自的 *index.html、index.css、index.js* 中。



具体怎么操作呢？



我们新建一个 *components* 目录，这里就存放我们每一个模块，一个模块就是一个 *HTML* 文件。

例如，在 *components* 目录下新建一个 *shortcut.html* 文件，*css* 目录下新建 *shortcut.css* 文件。



然后在 index.js 中，通过 load 方法来载入  *shortcut.html*  文件的内容，放入到 *div.shortcut .w* 当中，如下：

```js
// 加载 shortcut 模块中的内容
$('.shortcut .w').load('../components/shortcut.html')
```



如果要书写该模块对应的样式，就在  *shortcut.css* 文件中进行书写，写完后不要忘了在 *index.html* 中引入该 *css* 文件。



之后我们的开发，一个区域就可以像这样拆分成一个模块，方便后面的维护和管理。



## 完成首屏顶上快捷区域



接下来开始来写快捷区域。

首先还是分析，整体结构是什么样的？



![image-20210825160213514](https://xiejie-typora.oss-cn-chengdu.aliyuncs.com/2021-08-25-080213.png)



其实大致就分为两个区域，其中右边可以使用无序列表来做，所以整体的结构变成了



```html
<!-- 地理位置 -->
<div class="position">
    <span>四川</span>
</div>
<!-- 右侧导航栏 -->
<ul class="navbar"></ul>
```



右边的无序列表，里面是一个一个的 *li*，并且有一些 *li* 是用来做分隔线的，如下：



```html
<!-- 右侧导航栏 -->
<ul class="navbar">
    <!-- 登录注册 -->
    <li class="nav-item"></li>
    <!-- 中间竖线 -->
    <li class="spacer"></li>
    <!-- 我的订单 -->
    <li class="nav-item"></li>
    <!-- 中间竖线 -->
    <li class="spacer"></li>
    <!-- 我的京东 -->
    <li class="nav-item"></li>
    <!-- 中间竖线 -->
    <li class="spacer"></li>
    <!-- 京东会员 -->
    <li class="nav-item"></li>
    <!-- 中间竖线 -->
    <li class="spacer"></li>
    <!-- 企业采购 -->
    <li class="nav-item"></li>
    <!-- 中间竖线 -->
    <li class="spacer"></li>
    <!-- 客户服务 -->
    <li class="nav-item"></li>
    <!-- 中间竖线 -->
    <li class="spacer"></li>
    <!-- 网站导航 -->
    <li class="nav-item"></li>
    <!-- 中间竖线 -->
    <li class="spacer"></li>
    <!-- 手机京东 -->
    <li class="nav-item"></li>
</ul>
```



挂的 *nav-item* 说明是一个快捷栏项目，挂的 *spacer* 说明是一个中间的竖线。



整个快捷栏，分为 *2* 种，一种是没有隐藏区域的，类似【我的订单】、【京东会员】

一种是鼠标移动上去有隐藏区域的，例如【我的京东】、【企业采购】

<img src="https://xiejie-typora.oss-cn-chengdu.aliyuncs.com/2021-08-25-090525.png" alt="image-20210825170525015" style="zoom: 67%;" />



所以我们的 *li* 里面的内容也分为大致分为两种：



没有隐藏栏，【登陆注册】示例代码：

```html
 <!-- 登录注册 -->
<li class="nav-item">
  <div>
    <a href="#">你好，请登录</a>
    <a href="#" class="red">免费注册</a>
  </div>
</li>
```

有隐藏栏，【我的京东】示例代码：

```html
<!-- 我的京东 -->
<li class="nav-item">
  <!-- 挂了 dt-icon 类的元素，在 hover 时有样式变化 -->
  <div class="dt dt-icon">
    <a href="#">我的京东</a>
    <!-- 小三角图标 -->
    <i class="iconfont small">&#xe61e;</i>
  </div>
  <!-- 下面的隐藏栏 -->
  <div class="my-dropdown my-jd">
    <dl class="clearfix">
      <dd><a href="#">待处理订单</a></dd>
      <dd><a href="#">返修退换货</a></dd>
      <dd><a href="#">降价商品</a></dd>
      <dd><a href="#">消息</a></dd>
      <dd><a href="#">我的问答</a></dd>
      <dd><a href="#">我的关注</a></dd>
    </dl>
    <dl class="clearfix">
      <dd><a href="#">我的京豆</a></dd>
      <dd><a href="#">我的白条</a></dd>
      <dd><a href="#">我的优惠券</a></dd>
      <dd><a href="#">我的理财</a></dd>
    </dl>
  </div>
</li>
```



不管有没有隐藏栏，*li* 里面都有有个 *div*，*div* 下面有一个 *a* 代表具体的快捷栏项目。

如果有隐藏栏，就会多一个 *div.my-dropdown*（*my-dropdown* 是隐藏栏通用样式），然后里面有自定义列表 *dl* 。



根据这个规律，我们就可以完成整个右侧的快捷导航栏，代码如下：

```html
<!-- 右侧导航栏 -->
<ul class="navbar">
    <!-- 登录注册 -->
    <li class="nav-item">
        <div>
            <a href="#">你好，请登录</a>
            <a href="#" class="red">免费注册</a>
        </div>
    </li>
    <!-- 中间竖线 -->
    <li class="spacer"></li>
    <!-- 我的订单 -->
    <li class="nav-item">
        <!-- 挂了 dt 类的元素要设置左右 padding -->
        <div class="dt">
            <a href="#">我的订单</a>
        </div>
    </li>
    <!-- 中间竖线 -->
    <li class="spacer"></li>
    <!-- 我的京东 -->
    <li class="nav-item">
        <!-- 挂了 dt-icon 类的元素，在 hover 时有样式变化 -->
        <div class="dt dt-icon">
            <a href="#">我的京东</a>
            <!-- 小三角图标 -->
            <i class="iconfont small">&#xe61e;</i>
        </div>
        <!-- 下面的隐藏栏 -->
        <div class="my-dropdown my-jd">
            <dl class="clearfix">
                <dd><a href="#">待处理订单</a></dd>
                <dd><a href="#">返修退换货</a></dd>
                <dd><a href="#">降价商品</a></dd>
                <dd><a href="#">消息</a></dd>
                <dd><a href="#">我的问答</a></dd>
                <dd><a href="#">我的关注</a></dd>
            </dl>
            <dl class="clearfix">
                <dd><a href="#">我的京豆</a></dd>
                <dd><a href="#">我的白条</a></dd>
                <dd><a href="#">我的优惠券</a></dd>
                <dd><a href="#">我的理财</a></dd>
            </dl>
        </div>
    </li>
    <!-- 中间竖线 -->
    <li class="spacer"></li>
    <!-- 京东会员 -->
    <li class="nav-item">
        <div class="dt">
            <a href="#">京东会员</a>
        </div>
    </li>
    <!-- 中间竖线 -->
    <li class="spacer"></li>
    <!-- 企业采购 -->
    <li class="nav-item">
        <div class="dt dt-icon">
            <a href="#">企业采购</a>
            <!-- 小三角图标 -->
            <i class="iconfont small">&#xe61e;</i>
        </div>
        <!-- 下面的隐藏栏 -->
        <div class="my-dropdown my-company">
            <dl class="clearfix">
                <dd><a href="#">企业购</a></dd>
                <dd><a href="#">商用场景馆</a></dd>
                <dd><a href="#">工业品</a></dd>
                <dd><a href="#">礼品卡</a></dd>
                <dd><a href="#">丰客多商城</a></dd>
            </dl>
        </div>
    </li>
    <!-- 中间竖线 -->
    <li class="spacer"></li>
    <!-- 客户服务 -->
    <li class="nav-item">
        <div class="dt dt-icon">
            <span>客户服务</span>
            <!-- 小三角图标 -->
            <i class="iconfont small">&#xe61e;</i>
        </div>
        <!-- 下面的隐藏栏 -->
        <div class="my-dropdown my-serve">
            <dl class="clearfix">
                <dt>客户</dt>
                <dd><a href="#">帮助中心</a></dd>
                <dd><a href="#">售后服务</a></dd>
                <dd><a href="#">在线客服</a></dd>
                <dd><a href="#">意见建议</a></dd>
                <dd><a href="#">电话客服</a></dd>
                <dd><a href="#">客服邮箱</a></dd>
                <dd><a href="#">金融咨询</a></dd>
                <dd><a href="#">全球售客服</a></dd>
            </dl>
            <dl class="clearfix">
                <dt>商户</dt>
                <dd><a href="">合作招商</a></dd>
                <dd><a href="">成长中心</a></dd>
                <dd><a href="">商家后台</a></dd>
                <dd><a href="">京麦工作台</a></dd>
                <dd><a href="">商家帮助</a></dd>
                <dd><a href="">规则平台</a></dd>
            </dl>
        </div>
    </li>
    <!-- 中间竖线 -->
    <li class="spacer"></li>
    <!-- 网站导航 -->
    <li class="nav-item">
        <div class="dt dt-icon">
            <span>网站导航</span>
            <!-- 小三角图标 -->
            <i class="iconfont small">&#xe61e;</i>
        </div>
        <!-- 下面的隐藏栏 -->
        <div class="my-dropdown app clearfix">
            <dl class="clearfix">
                <dt>特色主题</dt>
                <dd><a href="">新品首发</a></dd>
                <dd><a href="">京东金融</a></dd>
                <dd><a href="">全球售</a></dd>
                <dd><a href="">国际站</a></dd>
                <dd><a href="">京东会员</a></dd>
                <dd><a href="">京东预售</a></dd>
                <dd><a href="">台湾售</a></dd>
                <dd><a href="">俄语站</a></dd>
            </dl>
            <dl class="clearfix">
                <dt>特色主题</dt>
                <dd><a href="">新品首发</a></dd>
                <dd><a href="">京东金融</a></dd>
                <dd><a href="">全球售</a></dd>
                <dd><a href="">国际站</a></dd>
                <dd><a href="">京东会员</a></dd>
                <dd><a href="">京东预售</a></dd>
                <dd><a href="">台湾售</a></dd>
                <dd><a href="">俄语站</a></dd>
            </dl>
            <dl class="clearfix">
                <dt>特色主题</dt>
                <dd><a href="">新品首发</a></dd>
                <dd><a href="">京东金融</a></dd>
                <dd><a href="">全球售</a></dd>
                <dd><a href="">国际站</a></dd>
                <dd><a href="">京东会员</a></dd>
                <dd><a href="">京东预售</a></dd>
                <dd><a href="">台湾售</a></dd>
                <dd><a href="">俄语站</a></dd>
            </dl>
        </div>
    </li>
    <!-- 中间竖线 -->
    <li class="spacer"></li>
    <!-- 手机京东 -->
    <li class="nav-item">
        <div class="dt">
            <span>手机京东</span>
        </div>
    </li>
</ul>
```



结构完成后，书写对应部分的 *css* 样式。

*css* 样式不在笔记中做记录，详细可以参阅源码文件。



## 完成头部区域



今天的最后一个任务，就是完成头部区域。

首先还是创建对应的模块文件 *header.html* 和 *header.css*，然后引入对应模块：

```js
// 加载 header 模块中的内容
$('.header .w').load('../components/header.html')
```



然后观察头部区域，可以看到整个头部区域也是可以分为 *3* 个部分的，如下：

![image-20210825172911815](https://xiejie-typora.oss-cn-chengdu.aliyuncs.com/2021-08-25-092912.png)



所以我们对应的结构如下：

```html
<div class="header-content">
    <!-- logo 区域 -->
    <div class="logo"></div>

    <!-- 搜索框 -->
    <div class="search-box"></div>

    <!-- 广告区域 -->
    <div class="ad"></div>
</div>
```



同样，先把这 *3* 个部分用边框标记出来，对应的 *css* 如下：



该模块的整体样式

```css
/* 整体样式开始 */

li {
    list-style: none;
}

a {
    text-decoration: none;
    font-weight: 200;
}

a.red {
    font-weight: 400;
    color: #e1251b !important;
}

.header-content {
    position: relative;
    width: 100%;
    height: 140px;
}

/* 整体样式结束 */
```



logo 部分样式占位

```css
/* logo 样式开始 */

.logo {
    width: 190px;
    height: 120px;
    overflow: hidden;
    position: absolute;
    top: 10px;
    outline: 1px solid;
}
```



搜索框部分样式占位

```css
/* 搜索框样式开始 */

.search-box {
    position: absolute;
    left: 200px;
    height: 100%;
    right: 190px;
    outline: 1px solid;
}
```



广告区域样式占位

```css
/* 广告区域样式开始 */

.ad {
    position: absolute;
    right: 0;
    bottom: 10px;
    width: 190px;
    height: 120px;
    outline: 1px solid;
}
```



至此，*header* 部分的布局就搞定了，如下：

![image-20210825173940432](https://xiejie-typora.oss-cn-chengdu.aliyuncs.com/2021-08-25-093941.png)



接下来我们逐一攻破，首先是 *logo*，这部分很简单，就是一张图片

```html
<!-- logo 区域 -->
<div class="logo">
  <img src="http://misc.360buyimg.com/mtd/pc/index_2019/1.0.0/assets/sprite/header/sprite.png" alt=""
       class="target" />
</div>
```



然后是搜索框，这个部分又可以分为 *4* 个部分，如下：

![image-20210825174238264](https://xiejie-typora.oss-cn-chengdu.aliyuncs.com/2021-08-25-094239.png)



所以我们对应的 *html* 结构如下：

```html
 <!-- 搜索框 -->
<div class="search-box">
  <!-- 搜索框表单 -->
  <div class="search-form"></div>
  <!-- 热门词汇 -->
  <div class="hotwords"></div>
  <!-- 购物车模块 -->
  <div class="settleup"></div>
  <!-- 导航栏区域 -->
  <ul class="navitems"></ul>
</div>
```



接下来依然逐一攻破，每部分对应的结构如下：

搜索框表单：

```html
<!-- 搜索框表单 -->
<div class="search-form">
  <input type="text" id="search-inp" placeholder="外置光驱" />
  <a href="#" class="search-btn iconfont">&#xe66d;</a>
  <!-- 联想项目 -->
  <ul class="search-list"></ul>
</div>
```

购物车模块：

```html
 <!-- 购物车模块 -->
<div class="settleup">
  <div class="cw-icon">
    <i class="iconfont">&#xe621;</i>
    <a target="_blank" href="//cart.jd.com/cart.action">我的购物车</a>
    <i class="ci-count" id="shopping-amount">0</i>
  </div>
</div>
```

导航栏区域：

```html
<!-- 导航栏区域 -->
<ul class="navitems">
  <li><a href="#" class="red">秒杀</a></li>
  <li><a href="#" class="red">优惠券</a></li>
  <li><a href="#">PLUS会员</a></li>
  <li><a href="#">品牌闪购</a></li>
  <li><a href="#">拍卖</a></li>
  <li><a href="#">京东家电</a></li>
  <li><a href="#">京东超市</a></li>
  <li><a href="#">京东生鲜</a></li>
  <li><a href="#">京东国际</a></li>
  <li><a href="#">京东金融</a></li>
</ul>
```



唯独没有“热门词汇”这一块，因为这一块是后面 *JS* 动态填入内容的。



接下来完善该部分 *css* 样式，具体的 *css* 不在笔记中列出，具体参阅源代码。

完成后的效果如下：

![image-20210825175145952](https://xiejie-typora.oss-cn-chengdu.aliyuncs.com/2021-08-25-095146.png)



至于广告区域，直接从官网拿来用即可

```html
<!-- 广告区域 -->
<div class="ad">
  <!-- 直接从京东官网将此部分结构拿过来即可 -->
  <a id="J_promo_lk" class="promo_lk"
     href="//pro.jd.com/mall/active/2S7ULD94H4vvkQc8qhZxBi4sHXw1/index.html?babelChannel=ttt4" target="_blank"
     clstag="h|keycount|head|adbtn_01" aria-label="推广位"
     style="background-image: url(&quot;//img30.360buyimg.com/babel/jfs/t1/182371/6/7822/28758/60bd8cb0Ec02474e4/7c65702ebe4c260c.png.webp&quot;); background-size: cover;">
  </a>
</div>
```



当前的效果如下：

![image-20210825175636362](https://xiejie-typora.oss-cn-chengdu.aliyuncs.com/2021-08-25-095636.png)



接下来，我们需要完成“热门词汇”这个部分。

前面也说了，这个部分是通过 *JS* 动态渲染的。正常真实项目中，这部分内容也是从服务器获取到的，而不是写死的。

但是我们现在没有服务器，怎么办呢？



我们可以使用 *Mock* 来模拟服务器提供的数据。

在项目根目录下新创建一个 *Api* 的目录，模拟发送请求的请求接口函数，目录下创建 *searchApi.js*，代码如下：



```js
// 热门关键词
Mock.mock('/hotwords', {
    'result|8-15': [{
        word: '@cword(2,5)',
        href: '@url(http)'
    }]
});

// 推荐的热门关键词
Mock.mock('/recommendWords', {
    word: '@cword(2,5)',
    href: '@url(http)'
})
```



这里我们创建了 *2* 个 *Mock* 拦截，一个是热门关键词，一个是推荐热门。然后在 *index.html* 中引入该文件。



接下来回到 *header.html*，通过 *ajax* 来请求数据，然后将拿到的数据渲染到“热门词汇”，如下：

```js
// 获取热门关键词业务逻辑
$.ajax({
  url: "/hotwords",
  dataType: "json",
  success: function (res) {
    // 拿到关键词之后 进行渲染
    // console.log(res); {result: Array(12)}
    // 拼接热门关键词的结构
    // 这里可以讲解不同的拼接方式

    // 拼接方式一
    // var str = res.result.reduce(function (prev, item) {
    //     return prev + `<a href="${item.href}">${item.word}</a>`;
    // }, "");

    // 拼接方式二
    var str = res.result.map(function (item) {
      return `<a href="${item.href}">${item.word}</a>`;
    }).join("");
    // console.log(str);
    // <a href="http://whrfudb.va/dejeayyhmn">分四地取及</a><a href="http://szgwkudi.中国互联.公司/pvvwy">公处</a>...
    // 渲染到页面当中
    $(".hotwords").html(str);
  },
});
```



由于第一个热门关键词是一直在变化的，所以我们需要书写一个计时器，然后每隔一段时间就重新请求热门关键词，如下：

```js
// 获取第一个随机的热门关键词业务逻辑
var recommendTimer = null;
function randomWord() {
  // 因为第一个热门关键词一直在变化，所以定义一个 2 秒的计时器，每隔
  recommendTimer = setInterval(function () {
    $.ajax({
      url: "/recommendWords",
      dataType: "json",
      success(res) {
        // console.log(res);  {word: "写参引分", href: "http://stzeds.za/ttjqhalf"}
        // 获取到推荐的热门关键词之后，更新第一个热门关键词
        $(".hotwords")
          .find("a")
          .eq(0)
          .text(res.word)
          .attr("href", res.href);
      },
    });
  }, 2000);
}
randomWord();
```



效果：

![image-20210825180956089](https://xiejie-typora.oss-cn-chengdu.aliyuncs.com/2021-08-25-100957.png)



-*EOF*-

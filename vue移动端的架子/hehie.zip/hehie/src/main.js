import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import Vant from 'vant';
import 'vant/lib/index.css';


//动态改变字体大小
(function () {
  function autoRootFontSize() {
    document.documentElement.style.fontSize = Math.min(screen.width, document.documentElement.getBoundingClientRect().width) / 750 * 28 + 'px';
  }
  window.addEventListener('resize', autoRootFontSize);
  autoRootFontSize(); 
})();

Vue.use(Vant);
Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')

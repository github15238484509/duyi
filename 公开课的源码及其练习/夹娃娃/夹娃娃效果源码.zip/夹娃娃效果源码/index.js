var game = {
  // 整个游戏涉及到的静态dom元素，方便后续使用
  doms: {
    button: document.querySelector('.button'), //按钮
    toyContainer: document.querySelector('.toy-container'), // 娃娃的容器
    claw: document.querySelector('.claw'), // 爪子
  },
  // 一些配置信息
  config: {
    duration: 1000, // 爪子从上到下经过的时间（毫秒）
    createToyDuration: 2000, // 创建娃娃的间隔时间（毫秒）
    clawMaxHeight: 350, // 爪子的最大高度
    toyMaxLeft: 470, // 娃娃的最大横坐标，超出就看不见了
    toyWidth: 200, // 娃娃的宽度
    toyCatchedLeft: [110, 170], // 玩具可以被抓住的横坐标范围
    toyMaxBottom: 270, // 娃娃被抓起后到达的最大高度
    animateDuration: 10, // 娃娃动画的间隔时间
  },
  // 整个游戏期间动态产生的所有娃娃对象
  toys: [],
  // 从数组中移除某个娃娃，同时，娃娃在页面上的元素也会被移除
  removeToy: function (toy) {
    var index = game.toys.indexOf(toy);
    if (index >= 0) {
      // 数组中有这个对象
      game.toys.splice(index, 1);
      toy.remove(); // 删除娃娃元素
    }
  },
  // 每隔一段时间，创建一个新娃娃对象，娃娃自动开始向右移动，新的娃娃对象需要加入到toys数组中
  // 娃娃对象本质就是一个dom对象
  createToys: function () {
    // 创建一个娃娃
    function _createToy() {
      var div = document.createElement('div');
      game.toys.push(div);
      // 设置div的样式
      div.className = 'toy';
      div.left = -game.config.toyWidth;
      div.style.left = div.left + 'px';
      game.doms.toyContainer.appendChild(div);

      // 设置计时器，每隔一段时间，left变化一次
      div.timerId = setInterval(function () {
        div.left++;
        div.style.left = div.left + 'px';
      }, game.config.animateDuration);
    }

    _createToy();
    setInterval(function () {
      // 先看看哪些娃娃可以删除掉
      for (var i = 0; i < game.toys.length; i++) {
        var toy = game.toys[i];
        if (toy.left >= game.config.toyMaxLeft) {
          // 删除掉
          game.removeToy(toy);
        }
      }
      // 再创建新的娃娃
      _createToy();
    }, game.config.createToyDuration);
  },
  // 将可以被抓住的娃娃移动到上方，然后消失
  moveCatchedToyUp: function () {
    // 循环判断每一个娃娃，目前能不能被抓住
    var range = game.config.toyCatchedLeft;
    for (var i = 0; i < game.toys.length; i++) {
      var toy = game.toys[i];
      if (toy.left >= range[0] && toy.left <= range[1]) {
        // 这个娃娃能被抓住，给我上去
        // 1. 停止移动
        clearInterval(toy.timerId);
        // 2. 上去
        toy.style.bottom = game.config.toyMaxBottom + 'px';
        // 3. 等它上去后，移除掉
        setTimeout(function () {
          game.removeToy(toy);
        }, game.config.duration);
        return;
      }
    }
  },
  // 爪一下，爪子先下，后上
  clawing: function () {
    game.doms.claw.style.height = game.config.clawMaxHeight + 'px';

    setTimeout(function () {
      // 等它下去后，将它变成合拢的状态
      game.doms.claw.className = 'claw';
      // 又上去
      game.doms.claw.style.height = '';
      // 等它上去后，又变成打开
      setTimeout(function () {
        game.doms.claw.className = 'claw open';
      }, game.config.duration);
    }, game.config.duration);
  },
};

game.createToys();
var isClawing = false; // 是否正在抓娃娃
game.doms.button.onclick = function () {
  if (isClawing) {
    return;
  }
  isClawing = true;
  game.doms.button.className = 'button press';
  setTimeout(function () {
    game.doms.button.className = 'button ';
    isClawing = false;
  }, game.config.duration * 2);

  game.clawing();
  // 当爪子到底部的时候，抓娃娃
  setTimeout(game.moveCatchedToyUp, game.config.duration);
};

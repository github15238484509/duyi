<template>
  <div class="home">这是首页</div>
</template>

<script>
import { apiAddress } from "@/request/api.js";
export default {
  name: "Home",
  components: {},
  created() {
    console.log(apiAddress({ name: 132 }));
  },
};
</script>

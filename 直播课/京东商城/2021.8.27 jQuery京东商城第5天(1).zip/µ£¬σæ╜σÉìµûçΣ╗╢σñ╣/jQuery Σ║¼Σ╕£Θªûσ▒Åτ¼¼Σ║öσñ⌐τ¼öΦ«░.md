# *jQuery* 京东首屏第五天笔记



今日目标：



- 完成用户区域
- 完成京东秒杀倒计时
- 完成秒杀区域轮播图
- *logo* 移入移出切换动画



## 完成用户区域



今天我们继续来做京东首屏，首先是用户区域。还是先分析整体结构，如下图

<img src="https://xiejie-typora.oss-cn-chengdu.aliyuncs.com/2021-08-26-051424.png" alt="image-20210826131424207" style="zoom:50%;" />



可以看到，整体可以分为上中下 *3* 个部分。

所以我们来到 *index.html* 中，找到 *fs-3* 的地方，创建 *3* 个 *div*，如下：

```html
<!-- 轮播图右侧 user 区域 -->
<div class="fs-3">
  <div class="user"></div>
  <div class="news"></div>
  <div class="service"></div>
</div>
```



接下来我们一块一块来做，首先是 *user* 这一块。创建一个 *user.html* 模块，结构所对应的代码大致如下：

> 下面只是大致结构代码，完整代码请参阅源码

```html
<!-- 头像区域 -->
<div class="J_user_avatar user_avatar">
    <a href="" aria-label="个人头像">
        <img src="" alt="" />
    </a>
</div>

<!-- 头像右侧信息 -->
<div class="user_show">
    <a class="user_tip">Hi~欢迎逛京东！</a>
    <p>
        <a class="user_login">登录</a>
        <a class="user_reg">注册</a>
    </p>
</div>

<!-- 下面两个按钮 -->
<div class="user_profit">
  <a href="" target="_blank">新人福利</a>
  <a href="" target="_blank">PLUS会员</a>
</div>
```



接下来引入该模块部分所对应的样式文件 *fs-3.css*

```css
/* 整体区域样式开始 */

.fs-3 {
    font-size: 12px;
}

/* 整体区域样式结束 */
```

```css
/* user 部分样式开始 */

.user {
    /* user 盒子 */
    height: 102px;
    background: #fff;
    position: relative;
    font-size: 12px;
    /* outline: 1px solid; */
}

.user .user_avatar {
    /* 头像区域 */
    position: absolute;
    left: 20px;
    top: 13px;
    width: 44px;
    height: 44px;
}

.user .user_avatar_lk {
    /* 头像区域 */
    display: block;
    width: 40px;
    height: 40px;
    border: 2px solid #fff;
    border-radius: 50%;
    overflow: hidden;
    -webkit-box-shadow: 0 2px 8px rgb(0 0 0 / 5%);
    box-shadow: 0 2px 8px rgb(0 0 0 / 5%);
}

.user .user_avatar_lk img {
    /* 头像区域 */
    display: block;
    width: 40px;
    height: 40px;
    border: 2px solid #fff;
    border-radius: 50%;
}

.user_show {
    /* 头像右侧信息 */
    position: absolute;
    top: 16px;
    left: 74px;
    right: 10px;
}

.user_show p {
    /* 头像右侧信息 */
    overflow: hidden;
    height: 20px;
    line-height: 20px;
    width: 100%;
    white-space: nowrap;
    text-overflow: ellipsis;
    color: #666;
}

.user .user_profit {
    /* 下面两个按钮区域 */
    height: 25px;
    font-size: 0;
    text-align: center;
    position: absolute;
    bottom: 10px;
    width: 100%;
    /* outline: 1px solid; */
}

.user .user_profit_lk {
    /* 两个按钮公共样式 */
    display: inline-block;
    margin: 0 5px;
    width: 70px;
    height: 25px;
    line-height: 25px;
    font-size: 12px;
    text-align: center;
    color: #fff;
    border-radius: 13px;
    background: #e1251b;
}

.user .user_profit_lk_plus {
    /* 右边黑色按钮 */
    background: #363634;
    color: #e5d790;
}

.user::after {
    /* 下面的那条线 */
    position: absolute;
    height: 1px;
    left: 15px;
    right: 15px;
    background: -webkit-gradient(linear, right top, left top, from(white), color-stop(#eeeeee), color-stop(#eeeeee), to(white));
    background: linear-gradient(270deg, white, #eeeeee, #eeeeee, white);
    content: " ";
    bottom: 0;
}

/* user 部分样式结束 */
```



效果如下：

<img src="https://xiejie-typora.oss-cn-chengdu.aliyuncs.com/2021-08-26-052952.png" alt="image-20210826132952209" style="zoom:50%;" />



接下来是中间的 *news* 部分，同样创建一个 *news.html* 模块，代码如下：

> 直接从官网获取即可

```html
<!-- 新闻头部 -->
<div class="news-hd">
    <h5 class="news_tit">京东快报</h5>
    <a href="//kuaibao.jd.com/?ids=232264456,790737,231877478,232262561" target="_blank" class="news_more"
        clstag="h|keycount||head|news_a">更多 <i class="iconfont">&#xe625;</i></a>
</div>

<!-- 新闻列表 -->
<ul class="news_list">
    <li class="news_item news_item__recommend">
        <a href="//kuaibao.jd.com/article?id=232264456" target="_blank" class="news_link"
            clstag="h|keycount||head|news_b01"><span class="news_tag">热评</span>时尚复古墨镜，凹造型的单品出门旅游就选它</a>
    </li>
    <li class="news_item news_item__recommend">
        <a href="//kuaibao.jd.com/article?id=790737" target="_blank" class="news_link"
            clstag="h|keycount||head|news_b02"><span class="news_tag">热门</span>冲奶粉不做这个动作，奶粉最贵都放浪费</a>
    </li>
    <li class="news_item news_item__recommend">
        <a href="//kuaibao.jd.com/article?id=231877478" target="_blank" class="news_link"
            clstag="h|keycount||head|news_b03"><span class="news_tag">热议</span>“樱”为有它，足不出户也可感受樱花清香</a>
    </li>
    <li class="news_item news_item__recommend">
        <a href="//kuaibao.jd.com/article?id=232262561" target="_blank" class="news_link"
            clstag="h|keycount||head|news_b04"><span class="news_tag">热门</span>新学期换新装，这样的笔记本让你更引人注目！</a>
    </li>
</ul>
```



在 *fs-3.css* 文件中追加如下的样式代码：

```css
/* news 部分样式开始 */

.news {
    /* news 整体盒子 */
    overflow: hidden;
    height: 130px;
    background: #fff;
}

.news .news-hd {
    /* 新闻头部 */
    height: 20px;
    padding: 10px 0 0;
    position: relative;
    line-height: 20px;
    font-size: 0;
    margin-bottom: 8px;
}

.news .news-hd .news_tit {
    /* 京东快报 */
    display: inline-block;
    font-size: 14px;
    margin-left: 15px;
    color: #333;
}

.news .news-hd .news_more {
    /* 更多 */
    position: absolute;
    right: 15px;
    top: 10px;
    font-size: 12px;
    color: #999;
}

.news .news_list {
    /* 新闻列表 */
    position: relative;
    margin: 0 15px;
    height: 88px;
}

.news .news_item {
    /* ul 下面的每一个 li */
    max-width: 160px;
    width: 160px;
    height: 16px;
    line-height: 16px;
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
    color: #999;
    margin-bottom: 6px;
}

.news_tag {
    /* 新闻快讯前面的红色分类词 */
    display: inline-block;
    position: relative;
    font-size: 12px;
    height: 16px;
    width: 35px;
    line-height: 16px;
    text-align: center;
    vertical-align: 0;
    color: #e1251b;
    background-color: rgba(225, 37, 27, .08);
    margin-right: 6px;
}

/* news 部分样式结束 */
```



最后在 *index.js* 中加载该模块文件

```js
$('.fs-3 .news').load('../components/news.html');
```



效果如下：



<img src="https://xiejie-typora.oss-cn-chengdu.aliyuncs.com/2021-08-26-053737.png" alt="image-20210826133736973" style="zoom:50%;" />



好，接下来要做 *service* 部分了，这部分就涉及 *JS* 代码了。

我们先创建一个 *service.html* 模块，然后从官网拿 *HTML* 和 *CSS* 代码，其中 *CSS* 代码追加到 *fs-3.css* 文件里面。

具体的 *HTML* 和 *CSS* 代码就不再笔记中做记录了，详细可以参阅源码。

当前的效果如下：



<img src="https://xiejie-typora.oss-cn-chengdu.aliyuncs.com/2021-08-26-054755.png" alt="image-20210826134755035" style="zoom:50%;" />



那么，这里有一个什么效果呢？看下动图演示：



<img src="https://xiejie-typora.oss-cn-chengdu.aliyuncs.com/2021-08-26-055004.gif" alt="2021-08-26 13.49.08" style="zoom:50%;" />



也就是说，当用户的鼠标移动到【话费】【机票】【酒店】以及【游戏】这几个图标的时候，会有一个向上滑动的效果。

滑动结束后，会显示对应的弹出层内容。



我们对弹出层不做过多的书写，写一个 *div* 占位，如下：

*service.html*

```html
<!-- 弹出层 -->
<div class="service_pop">
    <div>各个模块内容</div>
    <div class="close"></div>
</div>
```



接下来就要做这个滑动的效果了。

我们一步一步来。首先是前面 *4* 个图标才会触发这个特效，所以我们需要给前面 *4* 个图标绑事件。

那么问题来了，我怎么知道是前 *4* 个呢？

仔细观察，你会发现前面 *4* 个 *li* 都挂有 *service_frame* 类，所以我们绑定事件如下：

```js
// 进入 li 的时候
// 前面 4 个 li，hover 的时候要 pop，所以挂上 service_frame 类
$('.service_frame').mouseenter(function () {
  console.log('OK')
})
```



接下来就是事件里面具体要做的事情，主要就是滑动，代码如下：

```js
// 进入 li 的时候
// 前面 4 个 li，hover 的时候要 pop，所以挂上 service_frame 类
$('.service_frame').mouseenter(function () {
  if ($(this).hasClass('service_frame2')) {
    // 进入此 if，说明用户是移动到的游戏上面
    // 主要的逻辑就是游戏这个盒子向上移动 55（一个 li 的高度），其他的盒子向上移动 28（图标的高度）
    $(this).animate({
      marginTop: -55 // 55 是一个 li.service_item 项目的高度
    }).siblings('.service_frame').animate({
      marginTop: -28 // 28 源于图标的高度 
    })
  } else {
    // 说明用户移动到的是第一排的 3 个图标
    $('.service_frame').not('.service_frame2').animate({
      marginTop: -28
    })
  }
})
```

这里，我们用了一个 *if...else* 进行分支，因为用户鼠标移动到第一排和第二排的滑动距离是不一样的，如果有 *service_frame2* 类名，说明是“游戏”图标上面，否则则是第一排的 *3* 个图标上。

那么具体移动多少呢？

我们看到如果是第一排 *3* 个图标，则移动 *28* 像素（*28* 源于图标高度）

如果是第二排“游戏”图标，则移动 *55* 像素（*55* 源于一个 *li* 的高度）

> 注意，移动是所有图标都要移动，并不是只移动前 *4* 个。



接下来，将下面的弹出层移动上来，如下：

```js
// 弹出层移入，34 源于 240（service 高度） - 206（弹出层高度）
$('.service_pop').animate({
  top: 34 /* 240 - 206 */
});
```



为当前项目添加下面的横线：

```js
// 这样该 li 下面的文字就会有红色小横线
$(this).addClass('service_active').siblings().removeClass('service_active')
```



最后为关闭按钮绑定事件，关闭按钮要做的事情就是反着移动

```js
// 点击关闭按钮所对应的事件
$('.close').click(function () {
  // 关闭窗口复原
  $('.service_pop').animate({
    top: 240
  });
  $('.service_frame').animate({
    marginTop: 0
  })
  $('.service_active').removeClass('service_active');
})
```



## 完成京东秒杀倒计时



最后是京东秒杀区域，首先我们还是来划分区域。

![image-20210826150344145](https://xiejie-typora.oss-cn-chengdu.aliyuncs.com/2021-08-26-070344.png)



整体分为 *2* 个区域，所以我们新创建一个 *seckill.html* 模块，写入如下的代码：

```html
<!-- 秒杀模块 -->
<div class="clearfix">
    <!-- 京东秒杀倒计时 -->
    <div class="seckill-count"></div>
    <!-- 两个轮播图 -->
    <div class="seckill-content">
        <div class="seckill-list"></div>
        <div class="seckill-brand"></div>
    </div>
</div>
```



接下来创建 *seckill.css*（具体样式代码参阅源码），在 *index.html* 中引入，然后在 *index.js* 中引入 *seckill.html* 模块。

```js
// 秒杀模块
$('.seckill').load('../components/seckill.html');
```



在京东秒杀倒计时里面，主要分为“时”、“分”、“秒"，具体结构如下：

```html
<!-- 京东秒杀倒计时 -->
<div class="seckill-count">
  <a class="seckill-countdown" href="//miaosha.jd.com" target="_blank" clstag="h|keycount|core|seckill_a">
    <div class="countdown-title">京东秒杀</div>
    <div>
      <div class="countdown-desc"><strong>22:00</strong> 点场 倒计时</div>
      <span class="timmer countdown-main">
        <span class="timmer__unit timmer__unit--hour">01</span>
        <span class="timmer__unit timmer__unit--minute">46</span>
        <span class="timmer__unit timmer__unit--second">57</span>
      </span>
    </div>
  </a>
</div>
```



接下来来书写倒计时的业务逻辑，代码如下：

```js
var endTime = new Date('2021-08-26 22:00'); // 设置结束时间
// console.log(endTime);

var seckillTimer = setInterval(function () {
  var nowTime = new Date();
  // 剩余毫秒数
  var disTime = endTime.getTime() - nowTime.getTime(); // 计算现在到结束时间的时间差（单位：毫秒）
  if (disTime < 0) {
    // 进入此 if，说明已经超过结束时间，那么结束计时器
    clearInterval(seckillTimer);
  } else {
    // 剩余小时数
    var hour = parseInt(disTime / 1000 / 60 / 60);
    // 剩余分钟数
    var minutes = parseInt(disTime / 1000 / 60 % 60);
    // 剩余秒数
    var seconds = parseInt(disTime / 1000 % 60);
    if (hour < 10) {
      hour = '0' + hour;
    }
    if (minutes < 10) {
      minutes = '0' + minutes;
    }
    if (seconds < 10) {
      seconds = '0' + seconds;
    }
    $('.timmer__unit--hour').text(hour);
    $('.timmer__unit--minute').text(minutes);
    $('.timmer__unit--second').text(seconds)
  }
}, 1000)
```



## 完成秒杀区域轮播图



秒杀区域有两个轮播图。轮播图我们在前面已经写过了，直接使用轮播插件来写即可。

首先创建两个轮播模块 *seckillList.html* 和 *seckillBrand.html*，两个文件里面书写轮播图具体项目。（具体代码请参阅源码）



接下来在 *seckill.html* 的 *JS* 中使用轮播插件，传入配置项即可。代码如下：

```js
// 加载两个轮播图内容
$('.seckill-content').find('.seckill-list').load('../components/seckillList.html', function () {
  $(this).swiper({
    contentList: $(this).find('.seckill-list-item'),
    type: 'animate',
    autoChangeTime: 10000,
    showSpots: false,
    showChangeBtn: 'always',
    width: 800,
    height: 260

  })
});
$('.seckill-content').find('.seckill-brand').load('../components/seckillBrand.html', function () {
  $(this).swiper({
    contentList: $(this).find('.brand-item'),
    type: 'animate',
    autoChangeTime: 2000,
    isAuto: true,
    spotPosition: 'center',
    showChangeBtn: 'hide',
    width: 180,
    height: 240
  })
});
```



## 完善其他细节部分



### *logo* 移入移出切换动画



前面我们已经书写了 *logo*，对应的就是一张图片，但是这里其实是有动态效果的。如下：



<img src="https://xiejie-typora.oss-cn-chengdu.aliyuncs.com/2021-08-26-072329.gif" alt="2021-08-26 15.23.06" style="zoom:67%;" />



回到我们的 *header.html*，之前我们放了一张静态的图片，其实下面还可以从官网拿到一张 *gif* 图片，如下：

```html
<!-- logo 区域 -->
<div class="logo">
  <!-- logo 区域是两张图，第一张是静态的 png，第二张是隐藏的 gif -->
  <img src="http://misc.360buyimg.com/mtd/pc/index_2019/1.0.0/assets/sprite/header/sprite.png" alt=""
       class="target" />
  <img src="http://img1.360buyimg.com/da/jfs/t1/14716/32/11447/94000/5c90a83bEaa611013/18490bf08654ba09.gif?v=0.36068380359321317"
       alt="" class="img-gif animate_end" />
</div>
```



但是现在在页面中并不能看到这张动图，因为 *header.css* 中设置了该动图的样式为 *display:none*

```css
.logo .img-gif {
  position: absolute;
  top: 0;
  left: 28px;
  width: 134px;
  height: 120px;
  background-color: #fff;
  display: none;
}
```



之后，我们要做的工作就很简单了，鼠标移动 *logo*  区域时，显示动图。动图的动画播放完毕后，回到 *logo* 图片。

具体的代码如下：

```js
// logo 区域的特效
var gifFadeOutTimer = null;
// 当鼠标移入时，我们要播放动画
$(".logo").mouseenter(function () {
  clearInterval(gifFadeOutTimer);
  // 鼠标移入到当前 logo 区域的时候  一定要有动画效果
  // animate_start 和 animate_end 这两个样式类没有对应的样式，只是为了做一个动画标识
  // animate_start 表示正在播放动画，animate_end 表示没有播放动画
  if ($(".img-gif").hasClass("animate_end")) {
    // 进入到此 if，说明当前没有在播放动画，那么我们要做的就是播放动画
    $(this)
      .find(".img-gif") // 找到 .img-gif 图片
      .fadeIn() // 设置淡入
    // 添加动画开始标识
      .addClass("animate_start")
      .removeClass("animate_end")
      .attr(
      "src",
      "http://img1.360buyimg.com/da/jfs/t1/14716/32/11447/94000/5c90a83bEaa611013/18490bf08654ba09.gif"
    ); // 重新设置动画对应的 gif 图片，否则下一次鼠标移入是播放完的状态
    // 并且在 4 秒中后，设置动画已经播放完毕的标识
    setTimeout(function () {
      $(".img-gif").addClass("animate_end").removeClass("animate_start");
    }, 4000);
  }
}).mouseleave(function () {
  // 鼠标移出的时候 必须要等到动画结束之后才能将图片隐藏
  if ($(".img-gif").hasClass("animate_end")) {
    // 进入此 if，说明动画已经播放完毕，将 .img-gif 淡出即可
    $(this).find(".img-gif").fadeOut();
  } else {
    // 进入 else，说明动画没有播放完毕，那么设置一个计时器不停的监听有没有播放完毕
    // 这里同样做了防抖的处理
    clearInterval(gifFadeOutTimer);
    // 动图执行完毕的监听
    gifFadeOutTimer = setInterval(function () {
      if ($(".img-gif").hasClass("animate_end")) {
        // 进入此 if，说明动画已经播放完毕，将 .img-gif 淡出即可
        // 同时不要忘了清除计时器
        $(".img-gif").fadeOut();
        clearInterval(gifFadeOutTimer);
      }
    }, 1000);
  }
});
```



### 广告背景图



广告背景图部分很简单，就是从官网拿的一段代码，放到轮播图区域的最后即可。如下：

```html
<!-- 轮播图区域 -->
<div class="fs w">
  
  <!-- 其他代码省略.... -->
  
  <!-- 背后的图片 -->
  <div id="J_fs_act" class="fs_act">
    <div clstag="h|keycount|head|adback_01" class="fs_act_wp"
         style="position: absolute; width:100%; height: 710px; left: 0px; top: 190px; margin: 0px; z-index:-999;">
      <a id="J_fs_act_lk" class="fs_act_lk" target="_blank"
         href="//pro.jd.com/mall/active/2S7ULD94H4vvkQc8qhZxBi4sHXw1/index.html?babelChannel=ttt9"
         style="display: block; background: url(&quot;//img13.360buyimg.com/babel/jfs/t1/178401/37/7878/121478/60bddb20Ef56cd9fe/90d95ac34946fa7b.png.webp&quot;) 50% 0px no-repeat; height: 710px;"></a>
    </div>
  </div>
</div>
```



效果：两边的广告就有了

![image-20210826153344970](https://xiejie-typora.oss-cn-chengdu.aliyuncs.com/2021-08-26-073345.png)



-*EOF*-

